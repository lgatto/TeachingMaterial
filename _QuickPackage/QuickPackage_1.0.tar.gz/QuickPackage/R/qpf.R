qpf <-
function() 
  packageDescription("QuickPackage")
